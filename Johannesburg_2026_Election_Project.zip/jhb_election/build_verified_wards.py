"""Build three target-ward histories only from geometrically comparable frames."""
from pathlib import Path
import hashlib
import pandas as pd
from audit_boundaries import read_polygons
from reconcile_official_results import extract,NAMES

ROOT=Path(__file__).resolve().parent
SELECTION={'79800021':[2011,2016,2021], '79800023':[2021], '79800087':[2016,2021]}

def run():
    paths={2011:'jhb_wards_2011_dissolved.geojson',2016:'jhb_wards_2016.geojson',
           2021:'jhb_wards_2021.geojson',2026:'jhb_wards_2026.geojson'}
    shapes={y:read_polygons(ROOT/'data/raw'/p,'WardID') for y,p in paths.items()}
    rows=[];crosswalk=[];geometry=[]
    for ward,years in SELECTION.items():
        for year in years:
            old,new=shapes[year][ward],shapes[2026][ward]
            change=old.symmetric_difference(new).area/new.area
            distance=old.hausdorff_distance(new)
            # Submillimetre differences reflect coordinate serialization, not drawn changes.
            assert distance<.001 and change<1e-6, 'Material boundary difference: exclude this frame'
            geometry.append({'ward_id':ward,'source_year':year,'target_year':2026,
                'symmetric_difference_fraction':change,'hausdorff_distance_m':distance,
                'status':'equivalent within 1 mm and 0.0001% area tolerance',
                'geometry_source':'MDB official ArcGIS layers; archived GeoJSON'})
            crosswalk.append({'source_year':year,'source_unit':ward,'target_ward':ward,
                'fraction':1.0,'evidence_url':'https://arcg.is/jOKyf0',
                'method':'full count transfer after polygon equivalence audit'})
            path=ROOT/'data/raw/wards'/f'{year}_{ward}.pdf'
            full,_,_=extract(path);total=int(full.ward_votes.sum())
            full['party']=full.official_party_name.map(NAMES).fillna('OTHER')
            counts=full.groupby('party').ward_votes.sum()
            from model import PARTIES
            for party in PARTIES:
                rows.append({'source_year':year,'source_unit':ward,'party':party,
                    'votes':int(counts.get(party,0)), 'ballot':'Ward',
                    'ward_total_valid':total,'evidence_class':'historical observation' if party!='OTHER' else 'derived residual',
                    'official_report':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    pd.DataFrame(rows).to_csv(ROOT/'data/verified_ward_history.csv',index=False)
    pd.DataFrame(crosswalk).to_csv(ROOT/'data/verified_ward_crosswalk.csv',index=False)
    pd.DataFrame(geometry).to_csv(ROOT/'data/selected_ward_geometry.csv',index=False)
    print('Built 6 comparable ward-election frames for target wards 21, 23 and 87.')

if __name__=='__main__':run()
