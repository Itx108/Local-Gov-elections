import sys
import unittest
from pathlib import Path
import pandas as pd
from shapely.geometry import box
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from model import load_data,shares_wide,rolling_diagnostics,sensitivity,scenario_leaders,verified_ward_forecasts
from audit_boundaries import audit

class RevisionTests(unittest.TestCase):
    def test_real_target_ward_predictions_and_admitted_geography(self):
        leaders,parties,metrics=verified_ward_forecasts()
        self.assertEqual(set(leaders.ward_id),{'79800021','79800023','79800087'})
        self.assertTrue(leaders.target_date.eq('2026-11-04').all())
        for _,group in parties.groupby('ward_id'):self.assertAlmostEqual(group.share.sum(),1)
        geometry=pd.read_csv(Path(__file__).resolve().parents[1]/'data/selected_ward_geometry.csv')
        self.assertTrue(geometry.hausdorff_distance_m.lt(.001).all())
        self.assertTrue(geometry.symmetric_difference_fraction.lt(1e-6).all())
        # Ward 23 has one admitted year: its missing validation must stay visible.
        self.assertFalse(metrics.ward_id.eq('79800023').any())
        self.assertIn('not available',leaders.set_index('ward_id').loc['79800023','validation'])

    def test_earlier_forecasts_exclude_future_outcomes(self):
        votes,turnout,*_=load_data();shares=shares_wide(votes)
        before,_=rolling_diagnostics(shares,turnout)
        changed=shares.copy();changed.loc[2021]=changed.loc[2021].iloc[::-1].to_numpy()
        after,_=rolling_diagnostics(changed,turnout)
        pd.testing.assert_frame_equal(before[before.test_year==2016],after[after.test_year==2016])

    def test_new_party_missing_is_distinct_from_zero(self):
        votes,_,_,context,_=load_data();shares=shares_wide(votes)
        scenarios=sensitivity(shares,context)
        new=scenarios[scenarios.party.isin(['MK','RISE Mzansi'])]
        self.assertTrue(new[new.provincial_weight==0].share.isna().all())
        self.assertTrue(new[new.provincial_weight>0].share.gt(0).all())
        for _,group in scenarios.groupby(['method','provincial_weight']):
            self.assertAlmostEqual(group.share.sum(),1)
        self.assertEqual(len(scenario_leaders(shares,context)),6)

    def test_geometry_finds_renumbering_and_split(self):
        # Test geometry units only: these are not fabricated election inputs.
        old={'oldA':box(0,0,2,1),'oldB':box(2,0,3,1)}
        new={'new1':box(0,0,1,1),'new2':box(1,0,2,1),'renumberedB':box(2,0,3,1)}
        result,outer=audit(old,new)
        self.assertTrue(outer['exact_outer_geometry_equal'])
        matches=result[result.equal_geometry]
        self.assertEqual(matches.iloc[0].source_ward,'oldB')
        self.assertEqual(matches.iloc[0].target_ward,'renumberedB')
        self.assertAlmostEqual(result[result.source_ward=='oldA'].source_area_fraction.sum(),1)

if __name__=='__main__':unittest.main()
