"""Meaningful integrity checks: forecast arithmetic and geography conservation."""
import sys
from pathlib import Path
import unittest
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from model import (load_data,shares_wide,backtest,ridge_forecast,forecast,
                   ward_scenarios,align_counts,simplex_projection)

class IntegrityTests(unittest.TestCase):
    def test_counts_and_forecast_reconcile(self):
        votes,turnout,wards,_,_=load_data()
        shares=shares_wide(votes)
        for method in ['Persistence','Ridge (alpha=0.5)']:
            f,t=forecast(shares,turnout,method)
            self.assertAlmostEqual(f.share.sum(),1)
            self.assertAlmostEqual(f.pr_votes_estimate.sum(),t['pr_valid_estimate'])
            self.assertLessEqual(t['pr_valid_estimate'],t['voters_estimate'])
            self.assertLessEqual(t['voters_estimate'],t['registered_estimate'])
            self.assertTrue(f.share.ge(0).all())
        self.assertTrue(ward_scenarios(wards).current_2026_ward_prediction.str.startswith('WITHHELD').all())

    def test_holdout_does_not_use_test_outcomes(self):
        votes,*_=load_data();shares=shares_wide(votes)
        before,_=ridge_forecast(shares.loc[[2011,2016]],2021)
        changed=shares.copy();changed.loc[2021]=np.roll(changed.loc[2021].to_numpy(),1)
        after,_=ridge_forecast(changed.loc[[2011,2016]],2021)
        np.testing.assert_allclose(before,after)

    def test_split_crosswalk_conservation_and_rejection(self):
        # Synthetic units here test algorithm integrity, not election outcomes.
        records=pd.DataFrame({'source_year':[2021,2021],'source_unit':['unit','unit'],
                              'party':['A','B'],'votes':[100,60]})
        cw=pd.DataFrame({'source_year':[2021,2021],'source_unit':['unit','unit'],
                         'target_ward':['target1','target2'],'fraction':[.25,.75],
                         'evidence_url':['test-fixture','test-fixture'],'method':['test','test']})
        aligned=align_counts(records,cw)
        self.assertEqual(aligned.estimated_votes.sum(),160)
        self.assertEqual(aligned[aligned.target_ward=='target1'].estimated_votes.sum(),40)
        with self.assertRaises(AssertionError):
            align_counts(records,cw.assign(fraction=[.25,.5]))
        with self.assertRaises(AssertionError):
            align_counts(records.assign(source_unit='unmapped'),cw)

    def test_negative_predictions_project_to_valid_simplex(self):
        p=simplex_projection([-.5,.2,1.4])
        self.assertTrue((p>=0).all())
        self.assertAlmostEqual(p.sum(),1)

if __name__=='__main__':
    unittest.main()
