"""Streamlit runtime checks and interaction-driven forecast reconciliation."""
import sys
import unittest
import types
import tempfile
import shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest

class DashboardTests(unittest.TestCase):
    def test_cached_unrelated_model_does_not_shadow_local_model(self):
        unrelated=types.ModuleType('model')
        previous=sys.modules.get('model')
        sys.modules['model']=unrelated
        try:
            at=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py')).run(timeout=30)
        finally:
            if previous is None:
                sys.modules.pop('model',None)
            else:
                sys.modules['model']=previous
        self.assertEqual(len(at.exception),0)
        self.assertEqual(at.metric[0].value,'ANC')

    def test_mismatched_local_model_has_actionable_message(self):
        with tempfile.TemporaryDirectory() as folder:
            app=Path(folder)/'app.py'
            shutil.copyfile(Path(__file__).resolve().parents[1]/'app.py',app)
            (Path(folder)/'model.py').write_text('PARTIES = []\n')
            at=AppTest.from_file(str(app)).run(timeout=30)
            self.assertEqual(len(at.exception),0)
            self.assertIn('NEW_PARTIES',at.error[0].value)
            self.assertIn('same package',at.error[0].value)

    def test_default_and_changed_assumptions(self):
        at=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py')).run(timeout=30)
        self.assertEqual(len(at.exception),0)
        initial=float(at.metric[1].value.replace(',',''))
        at.number_input[0].set_value(2600000).run()
        self.assertEqual(len(at.exception),0)
        self.assertGreater(float(at.metric[1].value.replace(',','')),initial)
        at.selectbox[0].set_value('Ridge (alpha=0.5)')
        at.slider[0].set_value(.5)
        at.run(timeout=30)
        self.assertEqual(len(at.exception),0)
        self.assertEqual(len(at.tabs),5)

if __name__=='__main__':unittest.main()
