# Johannesburg election analytics: revised assessment report

Information cutoff: **5 October 2026**. Prediction date: **4 November 2026**.

This revision verifies original IEC results and actual MDB polygons. The notebook and dashboard produce conditional numerical predictions. Remaining limitations concern independent validation, earlier metro outer-boundary changes, new entrants, and the final 2026 roll/slate. Forecasts describe electoral support; they do not identify who will govern.

## 1. Largest projected metro party

The municipal-only baseline projects **ANC**, with **33.2% of valid PR support**. Persistence repeats the 2021 composition. It is a forecast rule, not a learned ML estimator. Ridge regression is actually trained and evaluated, but does not outperform the baseline on the available 2021 share-MAE comparison: approximately 5.14 percentage points for Ridge versus 5.11 for persistence. This near tie and one inspected election do not demonstrate a reliable accuracy advantage.

The default baseline uses the 2021 footprint, whose union is near-equivalent to the 2026 metro footprint at source coordinate precision. Earlier metro footprints differ; their historical modelling comparisons remain provisional. Their differences are not silently adjusted by area fractions.

No projected named party exceeds 50% of PR support. Illustrative combinations include ANC + DA (58.7%), ANC + ActionSA (51.3%), and DA + ActionSA + EFF (53.7%). These are vote-share sums. Council majorities require complete ward winners, independent seats, council size and the compensatory seat calculation. No coalition compatibility, agreement probability or governing-party outcome is modelled. A plurality in votes is not a prediction of the mayor.

## 2. Party support for 4 November 2026

| Party/category | Projected PR share | Estimated PR votes |
|---|---:|---:|
| ANC | 33.2% | 325,000 |
| DA | 25.5% | 249,000 |
| ActionSA | 18.1% | 177,000 |
| EFF | 10.1% | 99,000 |
| OTHER | 4.6% | 45,000 |
| PA | 3.0% | 29,000 |
| IFP | 2.4% | 23,000 |
| FF+ | 1.3% | 13,000 |
| ACDP | 1.0% | 10,000 |
| Al Jama-ah | 0.8% | 8,000 |

Totals count valid PR ballots, not unique voters or Ward + PR combined ballots. Rounded counts need not sum exactly. OTHER is a residual category. MK and RISE Mzansi are unestimated in the municipal-only baseline because no municipal observations for these parties are supplied. Historical noncontest zeros are not future zero-support claims.

The separate 2024 provincial table supplies supporting scenarios with 25% and 50% blending. Both parties receive positive support in those scenarios; they are missing, rather than zero, in the unblended municipal estimate. Weights are assumptions, not trained transfer coefficients or probabilities. Scenario results and leaders are exported. Their min/max envelope is not a calibrated confidence interval. The final candidate slate remains unverified.

## 3. Three ward predictions on audited 2026 footprints

| 2026 ward | Projected leader | Ward-ballot share | Comparable history |
|---|---|---:|---|
| 21 | ANC | 42.7% | 2011,2016,2021 |
| 23 | DA | 50.5% | 2021 |
| 87 | DA | 71.1% | 2016,2021 |

The selected wards are now **21, 23 and 87**, replacing 24, 89 and 102. Actual polygon comparison showed material changes to the original three wards. The archived candidate audit documents these changes and excludes incompatible historical frames.

Ward 21 supplies three comparable elections and an ANC lead. Ward 23 supplies a more divided DA/ActionSA electorate. Ward 87 supplies a DA-majority case with a comparable 2016 election. This purposive selection prioritizes geography and contrasting historical support, not statistical representativeness of Johannesburg.

Every admitted history has less than 1 mm Hausdorff distance and less than 0.0001% symmetric-difference area relative to its 2026 target polygon. Observed distances are approximately 0.00013–0.00025 metres. These very small differences are consistent with coordinate serialization. The actual target geometry is drawn from MDB's public 2026 layer and matches the layer linked by its official mapping application. Provider metadata predates the examination cutoff. The DATE attribute denotes the future election effective date, not a future outcome observation.

The count crosswalk transfers whole observed ward counts only after this polygon comparison. Shares are recalculated from counts. The 2011 geographic service returned 260 features for 130 Johannesburg wards; within-year dissolve removes duplicate/multipart representation without duplicating votes. Raw and dissolved versions are archived.

Ward 21 compares Ridge with persistence using a 2021 holdout trained on 2011/2016. Persistence wins MAE narrowly (7.28 versus 7.34 percentage points across the ten compositional outputs). Ward 87 evaluates persistence from 2016 to 2021; its share MAE is 2.65 percentage points. Ward 23 has only one comparable general election and cannot support historical forecast validation. It therefore uses an explicitly unvalidated persistence baseline. Its older 2011/2016 histories are excluded; ward 87's 2011 history is excluded. All current ward projections are conditional on historical support persisting and the historical party categories. No win probabilities are claimed.

## 4. Turnout and estimated voters

Projected IEC turnout numerator: **about 1,002,000**. Estimated turnout rate: **42.6%**. Estimated valid PR ballots: **about 977,000**.

The official historical denominator is registered population plus MEC7. Original turnout reports verify:

| Year | Registered | MEC7 | IEC turnout numerator | Recomputed rate |
|---|---:|---:|---:|---:|
| 2011 | 2,010,121 | 4,842 | 1,107,068 | 54.94% |
| 2016 | 2,239,966 | 6,384 | 1,281,864 | 57.06% |
| 2021 | 2,220,710 | 2,587 | 947,305 | 42.61% |

The future registered roll is estimated by carrying forward the verified 2024 value **2,348,781**. The future MEC7 adjustment is estimated by carrying forward its 2021 ratio to registration, giving approximately **2,736**. Thus the estimated turnout denominator is approximately **2,351,517**, rather than claiming a certified 2026 denominator. Historical participant/registered ratios remain available as a separate proxy, not the headline turnout measure.

Turnout uses a separately evaluated persistence/logit-Ridge comparison. Participant forecasts and valid PR forecasts use distinct conversions; PR-valid ballots per IEC turnout participant are carried forward from 2021. The IEC numerator is its reported turnout statistic, rather than an independently deduplicated person register.

At the baseline rate/adjustment ratio, a ±5% roll change gives approximately 952,000–1,052,000 participants. This is an assumption sensitivity, not interval coverage established by backtesting.

## 5. Data evidence and reproducibility

Original 2011, 2016 and 2021 detailed IEC reports, their extracted text, and 2024 provincial results are archived under data/raw. A reproducible parser checks the actual PR column, every named count, noncontest absence, the complete party total, and OTHER as a residual. **All 30 municipal model cells reconcile with zero difference.** The turnout reports and 2024 provincial table also reconcile. No secondary transcription is now needed for the municipal model counts.

The source register contains direct URLs. Raw snapshots have hashes and retrieval receipts. Source print dates/metadata support the cutoff audit; a file hash identifies bytes, not statistical validity. Historical observations, derived ratios/residuals and future predictions have explicit labels.

The geo tools retrieve source GeoJSON, compare actual polygons and archive the selected crosswalk. The full metro/ward overlap table is diagnostic geometry, not elector allocation. An area fraction is never relabelled as a voter fraction. The failed original Gauteng gazette download is recorded; an accessible official MDB feature layer provides the geometry comparison instead.

## 6. Validation and remaining limits

Additional expanding historical checks predict 2016 with only 2011, and 2021 with earlier elections. Party-count errors use training-only roll assumptions, so future registration is not leaked into historical count forecasts. A one-election training set supports a baseline check but does not establish a trend. The 2021 comparison is also used in model selection and has already been inspected, so its winning score is not an unbiased final accuracy estimate. Party outputs are dependent compositions, not independent test events.

A ward-union comparison detects **0.1682% area difference for the 2011 metro footprint** and **0.1650% for 2016**, relative to 2026. The 2021/2026 union symmetric difference is approximately 14.14 square metres over approximately 1,642.63 square kilometres, including numerical internal seams. Area differences do not quantify affected electors or party votes. Earlier metro diagnostics remain provisional until original voting-district counts are reconciled to the target footprint. The default 2021 persistence forecast avoids extrapolating a fitted trend across those earlier differences.

The assessment requires critical handling of comparability, not false assurances that every geography is identical. The selected ward alignment has been applied. Changed histories are excluded. The remaining metro difference is quantified, its effect is not invented, and the forecast's scope is restricted accordingly.

Further independent temporal validation, a larger aligned panel, verified current roll/slate and a justified new-party transfer model would strengthen the project. There is no basis for calibrated 95% intervals, election-win probabilities, or claims of general ward accuracy. A more complex algorithm cannot replace missing temporal events.

## 7. Software and dashboard

All 24 notebook code cells executed sequentially in-process with saved outputs. A separate Jupyter kernel could not launch on the preparation host; run the notebook in your installed Jupyter application. Streamlit application tests cover initial execution and changes to model, electoral roll and provincial scenario controls. Nine tests passed, checking forecasting arithmetic, training-only data, new-party missingness, target ward outputs and geometry conservation. Software tests do not establish election forecast accuracy.

The dashboard separates historical evidence, projections, validation, audited ward forecasts and sources. The complete project and standalone Streamlit folder include all required model inputs. Read CELL_BY_CELL_GUIDE.md for notebook instructions and README.md for installation and evidence reproduction.
