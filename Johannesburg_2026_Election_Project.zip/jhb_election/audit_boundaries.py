"""Compare supplied official GeoJSON ward polygons without joining by ward number.

python audit_boundaries.py old_wards.geojson final_2026_wards.geojson --id-field WardID

Inputs must both use EPSG:4326, complete polygons, and official documented vintages.
Uses equal-area projection for diagnostics. Does not infer elector split weights.
"""
import argparse
import json
from pathlib import Path
import pandas as pd
from shapely.geometry import shape
from shapely.ops import transform, unary_union
from pyproj import Transformer

def read_polygons(path,id_field):
    document=json.loads(Path(path).read_text())
    crs=document.get('crs',{}).get('properties',{}).get('name','EPSG:4326')
    if not (crs.endswith('4326') or crs.endswith('CRS84')):
        raise ValueError('Reproject inputs to EPSG:4326 first')
    project=Transformer.from_crs('EPSG:4326','EPSG:6933',always_xy=True).transform
    polygons={}
    for feature in document['features']:
        identifier=str(feature['properties'][id_field])
        if identifier in polygons:
            raise ValueError('Duplicate ward identifier')
        geometry=shape(feature['geometry'])
        if geometry.is_empty or not geometry.is_valid or geometry.geom_type not in ('Polygon','MultiPolygon'):
            raise ValueError('Invalid/non-polygon ward geometry')
        polygons[identifier]=transform(project,geometry)
    if not polygons:
        raise ValueError('Empty boundary file')
    return polygons

def audit(old,new):
    rows=[]
    for target_id,target in new.items():
        for source_id,source in old.items():
            overlap=target.intersection(source).area
            if overlap>0:
                rows.append({'source_ward':source_id,'target_ward':target_id,
                    'overlap_m2':overlap,'source_area_fraction':overlap/source.area,
                    'target_area_fraction':overlap/target.area,
                    'equal_geometry':bool(source.equals(target)),
                    'use':'geometry audit only; area fractions are not elector weights'})
    outer_old,outer_new=unary_union(list(old.values())),unary_union(list(new.values()))
    outer={'exact_outer_geometry_equal':bool(outer_old.equals(outer_new)),
           'outer_symmetric_difference_m2':outer_old.symmetric_difference(outer_new).area,
           'historical_ward_count':len(old),'target_ward_count':len(new),
           'old_internal_overlap_m2':sum(p.area for p in old.values())-outer_old.area,
           'new_internal_overlap_m2':sum(p.area for p in new.values())-outer_new.area,
           'status':'computed comparison; source vintage and coverage still require review'}
    return pd.DataFrame(rows),outer

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('historical');parser.add_argument('target')
    parser.add_argument('--id-field',default='WardID')
    parser.add_argument('--output',default='outputs')
    args=parser.parse_args()
    result,outer=audit(read_polygons(args.historical,args.id_field),read_polygons(args.target,args.id_field))
    output=Path(args.output);output.mkdir(exist_ok=True)
    result.to_csv(output/'ward_polygon_overlap.csv',index=False)
    (output/'metro_boundary_comparison.json').write_text(json.dumps(outer,indent=2))
    print(json.dumps(outer,indent=2))
