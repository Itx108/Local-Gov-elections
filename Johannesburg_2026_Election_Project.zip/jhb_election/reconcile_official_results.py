"""Extract actual PR columns from archived IEC PDFs and reconcile every model cell."""
from pathlib import Path
import hashlib
import pandas as pd
import pdfplumber

ROOT=Path(__file__).resolve().parent
NAMES={'AFRICAN NATIONAL CONGRESS':'ANC','DEMOCRATIC ALLIANCE':'DA',
       'DEMOCRATIC ALLIANCE/DEMOKRATIESE ALLIANSIE':'DA',
       'ECONOMIC FREEDOM FIGHTERS':'EFF','ACTIONSA':'ActionSA',
       'PATRIOTIC ALLIANCE':'PA','INKATHA FREEDOM PARTY':'IFP',
       'VRYHEIDSFRONT PLUS':'FF+','AFRICAN CHRISTIAN DEMOCRATIC PARTY':'ACDP',
       'AL JAMA-AH':'Al Jama-ah'}

def number(text):
    text=str(text or '').strip().replace(',','').replace(' ','')
    return 0 if text=='-' else int(text)

def extract(path):
    rows=[];totals={}
    with pdfplumber.open(path) as pdf:
        for page_number,page in enumerate(pdf.pages,1):
            for table in page.extract_tables():
                if not any(len(r)>=11 for r in table):
                    continue  # Decorative report header boxes are not ballot tables.
                assert any(len(r)>3 and r[3]=='PR' for r in table), 'Unexpected table header/column order'
                for r in table:
                    name=' '.join((r[0] or '').split())
                    if name.startswith('Total '):
                        totals[name]=r
                    elif len(r)>=11 and name not in ('','Party Name'):
                        rows.append({'official_party_name':name,'ward_votes':number(r[1]),
                                     'pr_votes':number(r[3]),'page':page_number})
    full=pd.DataFrame(rows)
    total=number(totals['Total Valid Votes'][3])
    assert full.pr_votes.sum()==total, 'Complete PR table does not reconcile'
    return full,total,totals

def run():
    votes=pd.read_csv(ROOT/'data/metro_pr.csv')
    sources=pd.read_csv(ROOT/'data/sources.csv').set_index('source_id')
    audit=[];complete=[]
    for year in (2011,2016,2021):
        source_id=f'LGE{year}';path=ROOT/'data/raw'/f'{source_id}.pdf'
        full,total,totals=extract(path)
        full['year']=year;complete.append(full)
        full['party']=full.official_party_name.map(NAMES)
        named=full.dropna(subset=['party']).set_index('party')
        bundled=votes[votes.year==year]
        for r in bundled.itertuples():
            if r.party=='OTHER':
                actual=int(full[full.party.isna()].pr_votes.sum());page='all pages'
                status='derived from archived complete official PR table'
            elif r.party in named.index:
                actual=int(named.loc[r.party,'pr_votes']);page=str(named.loc[r.party,'page'])
                status='matched archived original IEC PR column'
            else:
                actual=0;page='complete report'
                status='absent from complete official contest table; structural historical zero'
            audit.append({'year':year,'party':r.party,'bundled_pr_votes':r.votes,
                          'primary_pr_votes_checked':actual,'difference':r.votes-actual,
                          'verification_status':status,'evidence_url':sources.loc[source_id,'url'],
                          'evidence_location':f'Page {page}; PR count column',
                          'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'review_date':'2026-10-05'})
        assert total==bundled.votes.sum()
        # IEC reported turnout statistic is separate from the two ballot counts.
        tr=totals.get('Total Voter Turnout')
        if tr:
            numbers=[number(v) for v in tr[1:] if str(v or '').strip() not in ('','-')]
            historical=pd.read_csv(ROOT/'data/turnout.csv')
            assert numbers==[int(historical[historical.year==year].voters.iloc[0])]
    audit=pd.DataFrame(audit)
    assert audit.difference.eq(0).all(), 'Historical model counts disagree with IEC originals'
    audit.to_csv(ROOT/'data/verification_audit.csv',index=False)
    pd.concat(complete,ignore_index=True).to_csv(ROOT/'data/official_complete_metro_results.csv',index=False)
    votes['source_id']=votes.year.map(lambda y:f'LGE{y}')
    votes['retrieval_route']='archived original IEC PDF; extracted PR count column'
    votes.to_csv(ROOT/'data/metro_pr.csv',index=False)
    turnout=pd.read_csv(ROOT/'data/turnout.csv')
    for year in (2011,2016,2021):
        path=ROOT/'data/raw'/f'TURNOUT{year}.pdf'
        with pdfplumber.open(path) as pdf:
            total_rows=[r for p in pdf.pages for table in p.extract_tables() for r in table if r[0]=='Total']
        assert len(total_rows)==1
        row=total_rows[0];stored=turnout[turnout.year==year].iloc[0]
        assert [number(row[i]) for i in (1,2,3)]==[stored.registered,stored.mec7,stored.voters]
        printed_rate=float(row[4].replace('%','').replace(',','.'))/100
        assert abs(printed_rate-stored.voters/(stored.registered+stored.mec7))<.000051
    # Provincial context is a distinct ballot. Never merge it as a municipal year.
    path=ROOT/'data/raw/NPE2024.pdf';provincial=[]
    with pdfplumber.open(path) as pdf:
        for p in pdf.pages:
            for table in p.extract_tables():
                for r in table:
                    if len(r)==4 and r[0] not in ('','Party Name','Total Valid Votes','Spoilt Votes','Total Votes Cast'):
                        try:provincial.append((' '.join(r[0].split()),number(r[2])))
                        except ValueError:continue
    counts=dict(provincial)
    assert sum(counts.values())==1415740
    mapping={**NAMES,'UMKHONTO WESIZWE':'MK','RISE MZANSI':'RISE Mzansi'}
    expected={mapping[n]:v for n,v in counts.items() if n in mapping}
    expected['OTHER']=sum(v for n,v in counts.items() if n not in mapping)
    context=pd.read_csv(ROOT/'data/provincial_2024.csv')
    assert context.set_index('party').votes.to_dict()==expected
    source_table=sources.reset_index()
    source_table.loc[source_table.source_id.isin(['LGE2011','LGE2016','LGE2021']), 'access_status']='Original PDF archived; every model PR cell and full party total reconciled by extraction code'
    source_table.loc[source_table.source_id=='NPE2024','access_status']='Original PDF archived; supporting provincial ballot, not municipal outcome'
    source_table.to_csv(ROOT/'data/sources.csv',index=False)
    print(f'{len(audit)} model cells reconciled against original IEC PDFs; differences all zero.')

if __name__=='__main__':run()
