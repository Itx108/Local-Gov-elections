"""Archive linked official PDFs and extraction text; never replace model data silently.

Run on a computer with IEC/MDB access: python collect_official_sources.py
Publication/cutoff eligibility and ballot-column checks require review of the files.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import re
import urllib.request
import pandas as pd

ROOT=Path(__file__).resolve().parent

def collect(row):
    target=ROOT/'data'/'raw'/f'{row.source_id}.pdf'
    ward=re.fullmatch(r'WARD_(\d{4})_(\d+)',row.source_id)
    if ward:
        year,number=ward.groups()
        target=ROOT/'data/raw/wards'/f'{year}_79800{int(number):03d}.pdf'
    result={'source_id':row.source_id,'url':row.url,
            'attempted_at_utc':datetime.now(timezone.utc).isoformat(),
            'declared_available_by':row.available_by,
            'cutoff_eligibility':'requires publication/version review'}
    try:
        request=urllib.request.Request(row.url,headers={'User-Agent':'Johannesburg academic election analytics'})
        with urllib.request.urlopen(request,timeout=20) as response:
            content=response.read(32*1024*1024+1)
        if len(content)>32*1024*1024:
            raise ValueError('Report exceeds 32 MiB limit')
        if not content.startswith(b'%PDF-'):
            raise ValueError('Response is not a PDF; do not archive HTML as results')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(content)
        result.update(status='archived',file=target.name,bytes=len(content),
                      sha256=hashlib.sha256(content).hexdigest())
        try:
            import pdfplumber
            with pdfplumber.open(target) as pdf:
                text='\n\n'.join(f'PAGE {i+1}\n{page.extract_text() or ""}' for i,page in enumerate(pdf.pages))
            target.with_suffix('.txt').write_text(text)
            result['extraction']='text extracted; verify ballot columns before changing counts'
        except Exception as error:
            result['extraction']=f'Not extracted: {type(error).__name__}'
    except Exception as error:
        result.update(status='failed',error=str(error))
    return result

if __name__=='__main__':
    sources=pd.read_csv(ROOT/'data/sources.csv')
    selected=sources[sources.source_id.str.match(r'^(LGE\d+|TURNOUT\d+|NPE2024|WARD_\d+_\d+|MDB)$')]
    with ThreadPoolExecutor(max_workers=5) as pool:
        results=list(pool.map(collect,selected.itertuples(index=False)))
    output=ROOT/'outputs';output.mkdir(exist_ok=True)
    (output/'retrieval_receipts.json').write_text(json.dumps(results,indent=2))
    print(pd.DataFrame(results)[['source_id','status']].to_string(index=False))
    print('Receipt: outputs/retrieval_receipts.json. Failed downloads do not verify source data.')
