"""Create the assessment notebook and cell-by-cell guide from shared code."""
from pathlib import Path
import argparse
import nbformat

ROOT=Path(__file__).resolve().parent
cells=[]
def step(title,explanation,code):
    cells.append(nbformat.v4.new_markdown_cell(f'## Cell {1+sum(c.cell_type=="code" for c in cells)}: {title}\n\n{explanation}'))
    cells.append(nbformat.v4.new_code_cell(code))

cells.append(nbformat.v4.new_markdown_cell('''# Johannesburg election analytics: 4 November 2026

Information cutoff: **5 October 2026**. All future outputs are conditional predictions, not election observations or political opinions.

Original IEC reports are archived and every municipal model PR count reconciles. Final MDB polygons have been compared. The selected target wards are **21, 23 and 87**. Older histories are included only where polygon equivalence is documented. Original wards 24, 89 and 102 were replaced after their boundary changes were observed.

The project fits Ridge and evaluates it against persistence. The baseline wins the available comparisons. Three metro elections and very few comparable ward transitions cannot support calibrated election-win probabilities. Earlier metro outer footprints have small measured differences and remain unaligned at the vote-count level; their backtests are provisional. The default metro baseline uses the near-equivalent 2021 footprint.

Extract the complete project ZIP. Keep this notebook, `model.py`, and `data/` together. Run cells sequentially in a Python kernel with the project requirements installed.
'''))
step('Load the project','Shared functions ensure the notebook and dashboard use identical calculations.', '''from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display
ROOT=Path.cwd()
if not (ROOT/'model.py').exists(): ROOT=ROOT/'jhb_election'
assert (ROOT/'model.py').exists(), 'Extract the complete ZIP and open the notebook from its project folder.'
sys.path.insert(0,str(ROOT))
from model import (load_data,shares_wide,ridge_forecast,backtest,forecast,
    turnout_backtest,rolling_diagnostics,sensitivity,scenario_leaders,
    align_counts,verified_ward_forecasts,coalition_arithmetic,run_all,PARTIES,CUTOFF,TARGET)
print('Cutoff:',CUTOFF,'Target:',TARGET)
votes,turnout,old_ward_evidence,context,sources=load_data()
OUTPUT=ROOT/'outputs';OUTPUT.mkdir(exist_ok=True)''')
step('Define four outputs','Choose ballot definitions before modelling. PR ballots and ward ballots are different targets.', '''display(pd.DataFrame([
['Metro leader','Largest named-party valid PR share'],
['Party support','Valid PR vote totals and shares'],
['Ward leaders','Largest ward-ballot shares in audited 2026 wards'],
['Turnout','IEC turnout numerator and rate using registered + MEC7']
],columns=['output','definition']))
print('Governing arrangements require seats and agreements; electoral leadership is the model target.')''')
step('Inspect direct source links','The original reports, GeoJSON, provider metadata and hashes are retained. Data dates and observation dates are separate.', '''display(sources[['source_id','title','url','available_by','access_status']])
assert pd.to_datetime(sources.available_by).max()<=pd.Timestamp(CUTOFF)''')
step('Verify official results','Run the extraction script against original archived PDFs. It verifies ballot columns, complete totals, turnout denominators and separate provincial context.', '''from reconcile_official_results import run as reconcile
reconcile()
audit=pd.read_csv(ROOT/'data/verification_audit.csv')
display(audit)
assert audit.difference.eq(0).all()''')
step('Inspect observations and derived residuals','OTHER is calculated from complete official party counts. Historical noncontest zeros do not imply future zero support.', '''display(votes)
display(pd.read_csv(ROOT/'data/official_complete_metro_results.csv').head())
assert not votes.duplicated(['year','party']).any()
assert votes.votes.ge(0).all()
display(votes.groupby('year').votes.sum().rename('valid_PR_total'))''')
step('Audit geography before comparing years','Ward numbers alone are insufficient. The audit excludes materially changed historical footprints. Earlier metro union differences are not converted to voter fractions.', '''display(pd.read_csv(ROOT/'data/geography_audit.csv'))
display(pd.read_csv(ROOT/'data/selected_ward_geometry.csv'))
display(pd.read_csv(ROOT/'outputs/candidate_ward_alignment.csv'))
print('2011 geometry has 260 raw features; within-year dissolve produces 130 wards. Votes are never duplicated.')''')
step('Review the actual count crosswalk','Selected footprints differ by less than 1 mm and 0.0001% area, consistent with coordinate serialization. Admitted histories use full count transfers, not averaged percentages.', '''history=pd.read_csv(ROOT/'data/verified_ward_history.csv',dtype={'source_unit':str})
crosswalk=pd.read_csv(ROOT/'data/verified_ward_crosswalk.csv',dtype={'source_unit':str,'target_ward':str})
display(crosswalk)
aligned=align_counts(history[['source_year','source_unit','party','votes']],crosswalk)
assert np.isclose(aligned.estimated_votes.sum(),history.votes.sum())
display(aligned.head(12))''')
step('Create municipal share targets','Three election years are three temporal events; party columns are compositional outputs, not independent election samples.', '''shares=shares_wide(votes)
display(shares)
assert np.allclose(shares.sum(axis=1),1)''')
step('Visualize historical support','Historical observations must be visibly separate from the future forecast.', '''fig,ax=plt.subplots(figsize=(10,5))
shares[['ANC','DA','EFF','ActionSA','PA']].mul(100).plot(ax=ax,marker='o')
ax.set(title='Observed Johannesburg municipal PR support',ylabel='Valid PR share (%)',xlabel='Election year')
ax.set_xticks([2011,2016,2021]);ax.grid(alpha=.2)
fig.tight_layout();fig.savefig(OUTPUT/'historical_support.png',dpi=160)
plt.show()''')
step('Fit a Ridge candidate','Time is measured in five-year units; alpha=0.5 is fixed. The model projects shares onto the nonnegative simplex. It is intentionally small.', '''ridge_2026,estimator=ridge_forecast(shares,2026)
display(pd.DataFrame({'party':ridge_2026.index,'ridge_2026_share':ridge_2026.values}))
print('Learned coefficients:',estimator.coef_.shape)
print('This is a fitted ML candidate; persistence is the forecasting baseline.')''')
step('Forecast 2021 from earlier data','Preprocessing and fitting exclude 2021 outcomes. Metro results remain provisional diagnostics because earlier outer boundaries are not count-aligned.', '''metrics,party_errors=backtest(shares)
display(metrics);display(party_errors)
selected=metrics.sort_values('mae_pp').iloc[0]['model']
print('Lower-MAE candidate:',selected)
print('2021 has already been inspected in development; this is not an untouched final test.')''')
step('Add the earlier forecasting check','2016 persistence uses only 2011. A one-election training sample cannot establish a useful trend, so Ridge is evaluated only with two or more training elections.', '''rolling,count_errors=rolling_diagnostics(shares,turnout)
display(rolling);display(count_errors)
rolling.to_csv(OUTPUT/'rolling_validation.csv',index=False)
count_errors.to_csv(OUTPUT/'count_validation.csv',index=False)''')
step('Validate turnout separately','Official historical MEC7 counts are now available. The correct historical denominator is registered electors plus MEC7; forecast MEC7 is an explicit estimate.', '''turnout['iec_rate']=turnout.voters/(turnout.registered+turnout.mec7)
display(turnout[['year','registered','mec7','voters','iec_rate']])
display(turnout_backtest(turnout))''')
step('Generate the metro prediction','The 2024 registered roll is carried forward as an estimated 2026 roll. PR-valid ballots per turnout participant and MEC7/registered ratios are carried forward from 2021.', '''metro_projection,turnout_projection=forecast(shares,turnout,selected)
display(metro_projection)
print(json.dumps(turnout_projection,indent=2))
print('Default metro prediction is a conditional baseline on the 2021 near-equivalent footprint.')''')
step('Report the electoral leader','Vote leadership does not determine the mayor or the governing coalition.', '''named=metro_projection[metro_projection.party!='OTHER'].iloc[0]
print(f'Projected PR leader for {TARGET}: {named.party}, {named.share:.1%}')
print('Governing party: not identified by this vote-support model.')''')
step('Handle parties absent from municipal history','MK and RISE Mzansi enter supporting 2024 provincial scenarios. Transfer weights are assumptions, not learned coefficients. No municipal-only estimate is presented for these parties.', '''scenarios=sensitivity(shares,context)
display(context)
display(scenarios.groupby('party').share.agg(['min','max']))
assert scenarios[(scenarios.party.isin(['MK','RISE Mzansi']))&(scenarios.provincial_weight==0)].share.isna().all()
print('Scenario envelopes are not calibrated confidence intervals.')''')
step('Check whether the leader changes','Show assumption-sensitive outcomes instead of treating the default leader as certain.', '''display(scenario_leaders(shares,context))
print('Scenario frequency is not an election-win probability.')''')
step('Quantify turnout assumption sensitivity','Report rounded participants, rate and denominator together. Rate variations and roll variations are stress tests.', '''print('Estimated IEC turnout numerator:',round(turnout_projection['voters_estimate'],-3))
print('Estimated turnout rate:',f"{turnout_projection['rate_estimate']:.1%}")
print('Estimated roll:',turnout_projection['registered_estimate'])
print('Estimated MEC7:',round(turnout_projection['mec7_estimate']))
display(pd.DataFrame([
{'roll_multiplier':m,'participants_estimate':m*turnout_projection['voters_estimate']}
for m in [.95,1,1.05]]))''')
step('Justify three selected wards','Ward 21 offers three comparable elections and an ANC lead; ward 23 a more divided DA/ActionSA contest; ward 87 a DA-majority case with two comparable elections. Selection is purposive, not representative.', '''display(history.groupby('source_unit').source_year.unique())
print('Ward 23 excludes 2011 and 2016. Ward 87 excludes 2011. These exclusions follow actual geometry comparisons.')''')
step('Predict leaders and party shares in the target wards','Where history allows, compare Ridge/persistence using a 2021 holdout. Ward 23 uses a transparent single-election baseline with no validation claim.', '''ward_leaders,ward_projection,ward_metrics=verified_ward_forecasts()
display(ward_leaders);display(ward_projection);display(ward_metrics)
assert ward_projection.groupby('ward_id').share.sum().round(10).eq(1).all()
assert ward_leaders.target_date.eq(TARGET).all()''')
step('Examine coalition arithmetic','These combinations exceed 50% of projected PR support. They are not official seat allocations or predictions of coalition agreement.', '''display(coalition_arithmetic(metro_projection))
print('Council-seat analysis needs full ward winners, independent seats, council size and allocation rules.')''')
step('Visualize the future output','Show rounded analytical outputs without implying calibrated precision.', '''fig,ax=plt.subplots(figsize=(9,5))
plot=metro_projection.sort_values('share')
ax.barh(plot.party,100*plot.share,color='#477CA8')
ax.set(title='Conditional PR forecast: 4 November 2026',xlabel='Projected valid PR share (%)')
fig.tight_layout();fig.savefig(OUTPUT/'forecast_sensitivity.png',dpi=160)
plt.show()''')
step('Export auditable predictions','The output files retain full arithmetic; reports round estimates. Hashes identify the exact data snapshot.', '''summary=run_all()
assert np.isclose(metro_projection.share.sum(),1)
assert np.isclose(metro_projection.pr_votes_estimate.sum(),turnout_projection['pr_valid_estimate'])
print(json.dumps(summary,indent=2))''')
step('Inspect completion and limitations','A successful app test is software validation, not proof of forecasting accuracy. Additional independent elections and metro voting-district alignment remain useful work.', '''display(pd.read_csv(ROOT/'data/completion_status.csv'))
print('Launch dashboard: python -m streamlit run app.py')
print('Run checks: python -m unittest discover -s tests -v')''')
cells.append(nbformat.v4.new_markdown_cell('''## Interpretation

The default baseline predicts ANC as the largest metro PR party, around 33.2%. Turnout is approximately 1,002,000 reported participants and 42.6% using an estimated registered-plus-MEC7 denominator. These are conditional predictions for 4 November 2026.

The model predicts ANC in ward 21 and DA in wards 23 and 87. Actual MDB polygons support the admitted histories; no unchanged-number assumption substitutes for geometry. The histories are short, and the final party slate is unverified. These are not calibrated win probabilities.

All 30 municipal PR cells reconcile with original IEC PDFs. Additional historical checks and count errors are supplied. Earlier metro footprints differ by around 0.17% of area, which is not a bound on affected voters. Thus their validation remains provisional. Do not describe the project as an accurate or fully calibrated forecast. Largest PR support does not establish who will govern.
'''))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true')
    parser.add_argument('--execute-inprocess',action='store_true');args=parser.parse_args()
    nb=nbformat.v4.new_notebook(cells=cells,metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'}})
    if args.execute:
        from nbclient import NotebookClient
        NotebookClient(nb,timeout=120,kernel_name='python3',resources={'metadata':{'path':str(ROOT)}}).execute()
    elif args.execute_inprocess:
        # Useful where the host disallows kernel sockets. Executes real cell code,
        # but does not claim a separate Jupyter kernel was verified.
        import io,contextlib,os,base64
        from unittest.mock import patch
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import IPython.display
        os.chdir(ROOT);namespace={'__name__':'__notebook__'};count=0
        for cell in nb.cells:
            if cell.cell_type!='code':continue
            count+=1;cell.execution_count=count;cell.outputs=[];buffer=io.StringIO()
            def display_capture(value):
                data={'text/plain':repr(value)}
                if hasattr(value,'to_html'):data['text/html']=value.to_html()
                cell.outputs.append(nbformat.v4.new_output('display_data',data=data))
            def plot_capture():
                data=io.BytesIO();plt.gcf().savefig(data,format='png',dpi=130)
                cell.outputs.append(nbformat.v4.new_output('display_data',data={'image/png':base64.b64encode(data.getvalue()).decode()}))
                plt.close('all')
            with patch.object(IPython.display,'display',display_capture),patch.object(plt,'show',plot_capture),contextlib.redirect_stdout(buffer):
                exec(compile(cell.source,f'cell-{count}','exec'),namespace)
            if buffer.getvalue():cell.outputs.append(nbformat.v4.new_output('stream',name='stdout',text=buffer.getvalue()))
        nb.metadata['execution_note']='24 real code cells executed sequentially in-process; separate kernel launch not verified on this host.'
    nbformat.write(nb,ROOT/'Johannesburg_2026_Election_Analytics.ipynb')
    guide='\n\n'.join(c.source if c.cell_type=='markdown' else '```python\n'+c.source+'\n```' for c in cells)
    (ROOT/'CELL_BY_CELL_GUIDE.md').write_text(guide)
    print('Created',sum(c.cell_type=='code' for c in cells),'notebook cells; executed:',args.execute or args.execute_inprocess)
