"""Reproducible, deliberately small-data election analytics.

No political preferences, individual targeting, or governance classifier.
"""
from pathlib import Path
from itertools import combinations
import json
import hashlib
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parent
CUTOFF = '2026-10-05'
TARGET = '2026-11-04'
LATEST_VERIFIED_ROLL = 2348781  # IEC 2024 provincial report, carried forward as an estimate.
PARTIES = ['ANC', 'DA', 'EFF', 'ActionSA', 'PA', 'IFP', 'FF+', 'ACDP', 'Al Jama-ah', 'OTHER']
NEW_PARTIES = ['MK', 'RISE Mzansi']

def load_data():
    votes = pd.read_csv(ROOT/'data/metro_pr.csv')
    turnout = pd.read_csv(ROOT/'data/turnout.csv')
    wards = pd.read_csv(ROOT/'data/ward_evidence.csv', dtype={'ward_id': str})
    context = pd.read_csv(ROOT/'data/provincial_2024.csv')
    sources = pd.read_csv(ROOT/'data/sources.csv')
    assert not votes.duplicated(['year','party']).any()
    assert (votes.votes >= 0).all()
    assert set(votes.party) == set(PARTIES)
    assert votes.groupby('year').party.nunique().eq(len(PARTIES)).all()
    expected = {2011:1090124, 2016:1255385, 2021:923724}
    assert votes.groupby('year').votes.sum().to_dict() == expected
    assert (turnout.voters <= turnout.registered).all()
    assert (turnout.voters >= turnout.pr_valid).all()
    assert pd.to_datetime(wards.event_date).max() <= pd.Timestamp(CUTOFF)
    assert pd.to_datetime(sources.available_by).max() <= pd.Timestamp(CUTOFF)
    return votes, turnout, wards, context, sources

def shares_wide(votes):
    wide = votes.pivot(index='year',columns='party',values='votes').reindex(columns=PARTIES)
    return wide.div(wide.sum(axis=1),axis=0)

def simplex_projection(values):
    """Euclidean projection onto nonnegative shares summing to one."""
    v = np.asarray(values,dtype=float)
    u = np.sort(v)[::-1]
    cssv = np.cumsum(u)-1
    rho = np.where(u-cssv/np.arange(1,len(u)+1)>0)[0][-1]
    theta = cssv[rho]/(rho+1)
    return np.maximum(v-theta,0)

def ridge_forecast(shares, year, alpha=0.5):
    # A five-year time unit makes the regularization scale explicit.
    X = ((shares.index.to_numpy()-2011)/5).reshape(-1,1)
    estimator = Ridge(alpha=alpha).fit(X,shares.to_numpy())
    raw = estimator.predict(np.array([[(year-2011)/5]]))[0]
    return pd.Series(simplex_projection(raw),index=shares.columns), estimator

def score(actual,predicted):
    a,p = np.asarray(actual), np.asarray(predicted)
    return {'mae_pp':float(100*np.abs(a-p).mean()),
            'rmse_pp':float(100*np.sqrt(np.mean((a-p)**2))),
            'max_error_pp':float(100*np.abs(a-p).max()),
            'total_variation_pp':float(50*np.abs(a-p).sum()),
            'named_leader_correct':bool(np.argmax(a[:-1])==np.argmax(p[:-1]))}

def backtest(shares):
    # One temporal holdout; parties are outputs, NOT independent samples.
    train = shares.loc[[2011,2016]]
    actual = shares.loc[2021]
    ridge,_ = ridge_forecast(train,2021)
    persistence = train.iloc[-1]
    rows=[]
    for name,pred in [('Persistence',persistence),('Ridge (alpha=0.5)',ridge)]:
        rows.append({'model':name,'train_end':2016,'test_year':2021,**score(actual,pred)})
    comparison=pd.DataFrame({'actual':actual,'persistence':persistence,'ridge':ridge})
    return pd.DataFrame(rows),comparison

def rolling_diagnostics(shares, turnout):
    """Expanding historical checks. 2016 uses one training election, baseline only.

    These checks are retrospective diagnostics, not an untouched final test:
    the 2021 results have already been inspected during development.
    """
    rows=[]
    count_rows=[]
    for year in sorted(shares.index)[1:]:
        train=shares.loc[shares.index<year]
        candidates={'Persistence':train.iloc[-1]}
        if len(train)>=2:
            candidates['Ridge (alpha=0.5)']=ridge_forecast(train,year)[0]
        ttrain=turnout[turnout.year<year]
        actual_t=turnout[turnout.year==year].iloc[0]
        for name,pred in candidates.items():
            rows.append({'model':name,'test_year':year,'training_elections':len(train),
                         **score(shares.loc[year],pred)})
            count_est=turnout_models(ttrain,year)[name]['pr_valid_estimate']
            actual_counts=shares.loc[year]*actual_t.pr_valid
            pred_counts=pred*count_est
            count_rows.append({'model':name,'test_year':year,
                'party_count_mae':float(abs(actual_counts-pred_counts).mean()),
                'valid_pr_count_error':float(count_est-actual_t.pr_valid),
                'roll_input':'last training election only'})
    return pd.DataFrame(rows),pd.DataFrame(count_rows)

def turnout_models(turnout,year=2026,registered_override=None):
    historical = turnout.sort_values('year').copy()
    historical['iec_rate'] = historical.voters/(historical.registered+historical.mec7)
    rates=historical.iec_rate.to_numpy()
    X=((historical.year.to_numpy()-2011)/5).reshape(-1,1)
    z=np.log(rates/(1-rates))
    estimator=Ridge(alpha=0.5).fit(X,z)
    predicted_z=float(estimator.predict([[(year-2011)/5]])[0])
    ridge_rate=float(1/(1+np.exp(-predicted_z)))
    # Current roll unavailable: repeat last roll, explicitly an estimate.
    registered=int(registered_override or historical.iloc[-1].registered)
    assert registered>0
    mec7_estimate=registered*float(historical.iloc[-1].mec7/historical.iloc[-1].registered)
    result={}
    for name,rate in [('Persistence',float(rates[-1])),('Ridge (alpha=0.5)',ridge_rate)]:
        voters=(registered+mec7_estimate)*rate
        # Valid PR votes per reported IEC turnout participant, not 2*voters.
        pr_valid_per_voter=float(historical.iloc[-1].pr_valid/historical.iloc[-1].voters)
        result[name]={'rate_proxy':voters/registered,'rate_estimate':rate,
                     'mec7_estimate':mec7_estimate,
                     'turnout_denominator_estimate':registered+mec7_estimate,
                     'mec7_status':'last municipal MEC7/registered ratio carried forward',
                     'registered_estimate':registered,
                     'voters_estimate':voters,'pr_valid_estimate':voters*pr_valid_per_voter,
                     'roll_status':'user supplied estimate' if registered_override else '2021 roll persistence estimate',
                     'pr_valid_per_voter':pr_valid_per_voter}
    return result

def turnout_backtest(turnout):
    train=turnout[turnout.year<2021]
    actual=turnout[turnout.year==2021].iloc[0]
    # Use last TRAINING roll, not actual 2021 roll, to forecast the count.
    predictions=turnout_models(train,year=2021)
    rows=[]
    for name,r in predictions.items():
        rows.append({'model':name,'rate_absolute_error_pp':100*abs(r['rate_estimate']-actual.voters/(actual.registered+actual.mec7)),
                     'voter_count_absolute_error':abs(r['voters_estimate']-actual.voters),
                     'registered_count_absolute_error':abs(r['registered_estimate']-actual.registered)})
    return pd.DataFrame(rows)

def forecast(shares, turnout, method='Ridge (alpha=0.5)',registered_override=None):
    if method=='Persistence':
        estimate=shares.loc[2021].copy()
    elif method=='Ridge (alpha=0.5)':
        estimate,_=ridge_forecast(shares,2026)
    else:
        raise ValueError('Unknown model')
    # Choose turnout separately; its holdout may favor a different estimator.
    tmetrics=turnout_backtest(turnout)
    turnout_choice=tmetrics.sort_values('rate_absolute_error_pp').iloc[0]['model']
    turnout_estimate=turnout_models(turnout,registered_override=registered_override or LATEST_VERIFIED_ROLL)[turnout_choice]
    turnout_estimate['roll_status']='user supplied estimate' if registered_override else '2024 IEC roll carried forward; 2026 roll unverified'
    table=pd.DataFrame({'party':estimate.index,'share':estimate.values})
    table['pr_votes_estimate']=table.share*turnout_estimate['pr_valid_estimate']
    table['evidence_class']='conditional 2026 prediction'
    table['ballot']='PR'
    table['model']=method
    table['target_date']=TARGET
    return table.sort_values('share',ascending=False),{**turnout_estimate,'turnout_model':turnout_choice}

def sensitivity(shares,context):
    """Explicit scenario envelope, not a calibrated probability interval."""
    p=shares.loc[2021].copy()
    r,_=ridge_forecast(shares,2026)
    basis=PARTIES+NEW_PARTIES
    c=context.set_index('party').votes.reindex(basis,fill_value=0)
    c=c/c.sum()
    rows=[]
    for method,base in [('Persistence',p),('Ridge (alpha=0.5)',r)]:
        base=base.reindex(basis,fill_value=0)
        for weight in [0.0,0.25,0.5]:
            mixed=(1-weight)*base+weight*c
            for party,value in mixed.items():
                rows.append({'method':method,'provincial_weight':weight,'party':party,
                             'share':np.nan if weight==0 and party in NEW_PARTIES else value,
                             'estimate_status':'unestimated' if weight==0 and party in NEW_PARTIES else 'scenario',
                             'evidence_class':'assumption-driven scenario'})
    return pd.DataFrame(rows)

def scenario_leaders(shares,context):
    rows=[]
    for (method,weight),g in sensitivity(shares,context).groupby(['method','provincial_weight']):
        ranked=g[g.party!='OTHER'].dropna(subset=['share']).sort_values('share',ascending=False)
        rows.append({'model':method,'provincial_weight':weight,'leader':ranked.iloc[0].party,
                     'leader_share':ranked.iloc[0].share,
                     'runner_up':ranked.iloc[1].party,
                     'lead_margin_pp':100*(ranked.iloc[0].share-ranked.iloc[1].share),
                     'interpretation':'sensitivity scenario; no win probability'})
    return pd.DataFrame(rows)

def ward_scenarios(wards,weight=0.2):
    out=[]
    for ward,g in wards.groupby('ward_id',sort=True):
        base=g[g.event_type=='LGE'].iloc[0]
        recent=g[g.event_type=='BY'].sort_values('event_date').iloc[-1]
        support=(1-weight)*base.focal_share+weight*recent.focal_share
        # No individual opposition vector: >50% is a sufficient lead condition.
        leader=base.focal_party if support>0.5 else 'Not identifiable from partial party data'
        out.append({'historical_ward_id':ward,'focal_party':base.focal_party,
                    'observed_2021_share':base.focal_share,'latest_by_share':recent.focal_share,
                    'scenario_2026_share':support,'scenario_leader':leader,
                    'scenario_min_share':min(base.focal_share,recent.focal_share),
                    'scenario_max_share':max(base.focal_share,recent.focal_share),
                    'geography':'2021 ward footprint; unchanged-boundary assumption',
                    'current_2026_ward_prediction':'WITHHELD: crosswalk not verified',
                    'evidence_class':'conditional historical-footprint scenario'})
    return pd.DataFrame(out)

def align_counts(records,crosswalk):
    """Source count -> target count with documented, source-normalized fractions.

    Inputs: records(source_year,source_unit,party,votes), crosswalk
    (source_year,source_unit,target_ward,fraction,evidence_url,method).
    Fractions must come from verified geography, never matching ward numbers.
    Split weights ideally use registered electors, not polygon area.
    """
    keys=['source_year','source_unit']
    req=set(keys+['target_ward','fraction','evidence_url','method'])
    assert req <= set(crosswalk.columns)
    assert not crosswalk.duplicated(keys+['target_ward']).any()
    assert crosswalk.fraction.between(0,1).all()
    assert np.allclose(crosswalk.groupby(keys).fraction.sum(),1,atol=1e-8)
    assert crosswalk.evidence_url.fillna('').str.len().gt(0).all()
    assert not records.duplicated(keys+['party']).any()
    assert records.votes.ge(0).all()
    joined=records.merge(crosswalk,on=keys,how='left',validate='many_to_many')
    assert joined.fraction.notna().all(), 'Unmapped sources: do not silently drop votes.'
    joined['estimated_votes']=joined.votes*joined.fraction
    assert np.isclose(joined.estimated_votes.sum(),records.votes.sum())
    return joined.groupby(['source_year','target_ward','party'],as_index=False).estimated_votes.sum()

def verified_ward_forecasts():
    """Target-2026 ward predictions with deliberately different history depths."""
    history=pd.read_csv(ROOT/'data/verified_ward_history.csv',dtype={'source_unit':str})
    cw=pd.read_csv(ROOT/'data/verified_ward_crosswalk.csv',dtype={'source_unit':str,'target_ward':str})
    aligned=align_counts(history[['source_year','source_unit','party','votes']],cw)
    forecasts=[];metrics=[];leaders=[]
    for ward,g in aligned.groupby('target_ward'):
        panel=g.pivot(index='source_year',columns='party',values='estimated_votes').reindex(columns=PARTIES,fill_value=0)
        shares=panel.div(panel.sum(axis=1),axis=0)
        method='Persistence'
        if len(shares)>=2:
            train=shares.iloc[:-1];actual=shares.iloc[-1]
            candidates={'Persistence':train.iloc[-1]}
            if len(train)>=2:
                candidates['Ridge (alpha=0.5)']=ridge_forecast(train,int(shares.index[-1]))[0]
            local=[]
            for name,pred in candidates.items():
                row={'ward_id':ward,'model':name,'train_end':int(train.index[-1]),
                     'test_year':int(shares.index[-1]),**score(actual,pred)}
                metrics.append(row);local.append(row)
            method=min(local,key=lambda r:r['mae_pp'])['model']
        estimate=shares.iloc[-1] if method=='Persistence' else ridge_forecast(shares,2026)[0]
        ranked=estimate.drop('OTHER').sort_values(ascending=False)
        leaders.append({'ward_id':ward,'projected_leader':ranked.index[0],
            'leader_share':ranked.iloc[0],'runner_up':ranked.index[1],
            'lead_margin_pp':100*(ranked.iloc[0]-ranked.iloc[1]),
            'model':method,'history_years':','.join(map(str,shares.index)),
            'validation':'one retrospective 2021 holdout' if len(shares)>=2 else 'not available: one comparable general election',
            'target_date':TARGET,'geography':'audited MDB 2026 ward footprint',
            'evidence_class':'conditional 2026 prediction'})
        for party,value in estimate.items():
            forecasts.append({'ward_id':ward,'party':party,'share':value,'ballot':'Ward',
                'model':method,'target_date':TARGET,'evidence_class':'conditional 2026 prediction'})
    return pd.DataFrame(leaders),pd.DataFrame(forecasts),pd.DataFrame(metrics)

def coalition_arithmetic(table):
    # Vote-share thresholds only. Never label these actual seat majorities.
    shares=table.set_index('party').share.drop('OTHER',errors='ignore')
    main=shares.nlargest(6)
    result=[]
    for size in [2,3]:
        for group in combinations(main.index,size):
            total=float(main.loc[list(group)].sum())
            if total>0.5 and all(float(main.loc[list(s)].sum())<=0.5
                                 for k in range(1,size) for s in combinations(group,k)):
                result.append({'combination':' + '.join(group),'combined_pr_share':total,
                               'interpretation':'vote-share arithmetic only; seats and agreement unmodelled'})
    return pd.DataFrame(result,columns=['combination','combined_pr_share','interpretation'])

def run_all():
    votes,turnout,wards,context,sources=load_data()
    shares=shares_wide(votes)
    metrics,detail=backtest(shares)
    choice=metrics.sort_values('mae_pp').iloc[0]['model']
    predicted,t=forecast(shares,turnout,choice)
    out=ROOT/'outputs';out.mkdir(exist_ok=True)
    predicted.to_csv(out/'metro_forecast.csv',index=False)
    metrics.to_csv(out/'validation.csv',index=False)
    detail.to_csv(out/'backtest_party_errors.csv')
    turnout_backtest(turnout).to_csv(out/'turnout_validation.csv',index=False)
    rolling,counts=rolling_diagnostics(shares,turnout)
    rolling.to_csv(out/'rolling_validation.csv',index=False)
    counts.to_csv(out/'count_validation.csv',index=False)
    scenario_leaders(shares,context).to_csv(out/'scenario_leaders.csv',index=False)
    sensitivity(shares,context).to_csv(out/'sensitivity.csv',index=False)
    ward_scenarios(wards).to_csv(out/'ward_scenarios.csv',index=False)
    ward_leaders,ward_party,ward_metrics=verified_ward_forecasts()
    ward_leaders.to_csv(out/'verified_ward_leaders.csv',index=False)
    ward_party.to_csv(out/'verified_ward_party_forecasts.csv',index=False)
    ward_metrics.to_csv(out/'verified_ward_validation.csv',index=False)
    coalition_arithmetic(predicted).to_csv(out/'coalition_arithmetic.csv',index=False)
    named=predicted[predicted.party!='OTHER'].iloc[0]
    summary={'cutoff':CUTOFF,'target_date':TARGET,'selected_vote_model':choice,
             'named_party_leader':named.party,'leader_pr_share':float(named.share),
             'turnout':t,'governing_party':'not identifiable from vote forecasts',
             'status':'official counts reconciled and selected wards aligned; limited validation and earlier metro boundary uncertainty',
             'data_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data').glob('*.csv')}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    print(json.dumps(run_all(),indent=2))
