# Evidence snapshot

Cutoff: 2026-10-05. Target: 2026-11-04.

All municipal PR counts are reconciled against archived original IEC detailed PDFs by reconcile_official_results.py. official_complete_metro_results.csv retains full named rows before model aggregation. OTHER is derived. Structural historical noncontest zeros are not future zero estimates.

turnout.csv includes registered population, MEC7 and IEC turnout numerator verified against original turnout report totals. The projected 2026 roll and MEC7 remain estimates.

provincial_2024.csv is a separately identified provincial ballot. It is supporting scenario evidence, not a municipal observation. MK and RISE Mzansi are explicit categories there.

verified_ward_history.csv and verified_ward_crosswalk.csv cover only admitted comparable histories for final wards 21, 23 and 87. selected_ward_geometry.csv records the actual comparison tolerances and results. Excluded histories must not be restored by matching ward numbers. 2011 geometry is dissolved within its own year to remove duplicate/multipart source representation; votes are not duplicated.

Earlier metro outer footprints differ by around 0.17% of area. No elector or party-vote adjustment is inferred from that area. Those temporal diagnostics remain provisional; the default forecast uses 2021 support on its near-equivalent 2026 metro footprint.

ward_evidence.csv and outputs/ward_scenarios.csv retain the original wards 24, 89 and 102 as historical-footprint scenarios only. They are superseded by outputs/verified_ward_leaders.csv for the assessment's three 2026 ward predictions.

Sources have direct URLs and conservative availability bounds; raw file receipts and provider metadata support review of dates and vintages. Hashes identify bytes, not proof of publication at a particular earlier date. raw files are included. See completion_status.csv for outstanding work.
