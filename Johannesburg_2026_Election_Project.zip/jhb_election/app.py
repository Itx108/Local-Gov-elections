from pathlib import Path
import json
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import importlib.util

st.set_page_config(page_title='Johannesburg | Election Lab',page_icon='📊',layout='wide')

# Always use this dashboard's sibling model.py. A generic `from model import`
# can resolve an older module already cached by another notebook/application.
_model_path=Path(__file__).resolve().parent/'model.py'
if not _model_path.is_file():
    st.error(f'Missing {_model_path}. Extract the complete Johannesburg_Streamlit ZIP into a new folder.')
    st.stop()
_spec=importlib.util.spec_from_file_location('_johannesburg_dashboard_model',_model_path)
_model=importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_model)
_required=('load_data','shares_wide','backtest','turnout_backtest','forecast',
           'sensitivity','ward_scenarios','coalition_arithmetic','LATEST_VERIFIED_ROLL',
           'CUTOFF','TARGET','PARTIES','NEW_PARTIES','rolling_diagnostics',
           'scenario_leaders','verified_ward_forecasts')
_missing=[name for name in _required if not hasattr(_model,name)]
if _missing:
    st.error(f'Incompatible model.py at {_model_path}. Missing: {", ".join(_missing)}. '
             'Stop Streamlit, extract the latest complete ZIP into a new folder, then restart it. '
             'app.py and model.py must come from the same package.')
    st.stop()
for _name in _required:
    globals()[_name]=getattr(_model,_name)

st.markdown('''<style>
.block-container{padding-top:2rem;max-width:1440px}
h1{letter-spacing:-1.6px;font-weight:750!important}
.eyebrow{color:#E2A84B;letter-spacing:3px;font-size:12px;font-weight:700}
.lede{color:#A8B6CA;font-size:18px;max-width:1000px;margin-bottom:24px}
[data-testid="stMetric"]{background:#172235;border:1px solid #2A3A51;border-radius:12px;padding:20px}
[data-testid="stMetricLabel"]{color:#A8B6CA}
[data-testid="stMetricValue"]{font-size:30px}
.note{background:#172235;border-left:3px solid #E2A84B;padding:18px;border-radius:5px;color:#C8D4E4}
</style>''',unsafe_allow_html=True)

@st.cache_data
def data():
    return load_data()

votes,turnout,wards,context,sources=data()
shares=shares_wide(votes)
metrics,detail=backtest(shares)
selected=metrics.sort_values('mae_pp').iloc[0]['model']

with st.sidebar:
    st.markdown('### ELECTION LAB')
    st.caption('Johannesburg · JHB · Gauteng')
    st.divider()
    method=st.selectbox('Vote-share model',metrics.model.tolist(),index=metrics.model.tolist().index(selected))
    st.caption(f'2021 holdout choice: {selected}. One test election gives weak evidence.')
    roll=int(st.number_input('Estimated 2026 registered roll',min_value=1,value=LATEST_VERIFIED_ROLL,step=1000))
    st.caption('Default = 2024 IEC roll carried forward. This is an estimate, not the certified 2026 roll.')
    weight=st.slider('2024 provincial scenario weight',0.0,0.5,0.0,0.05)
    st.caption('0 = municipal model. Positive weights are assumptions; cross-election transfer is unvalidated.')
    st.divider()
    st.caption(f'Information cutoff: {CUTOFF}\n\nElection date: {TARGET}')

base,t=forecast(shares,turnout,method,roll)
table=base.set_index('party').reindex(PARTIES+NEW_PARTIES,fill_value=0)
if weight>0:
    provincial=context.set_index('party').votes.reindex(table.index,fill_value=0)
    table['share']=(1-weight)*table.share+weight*provincial/provincial.sum()
    table['pr_votes_estimate']=table.share*t['pr_valid_estimate']
    kind='Assumption-driven scenario'
else:
    kind='Conditional municipal forecast'
table=table.reset_index().sort_values('share',ascending=False)
leader=table[~table.party.isin(['OTHER']+NEW_PARTIES)].iloc[0] if weight==0 else table[table.party!='OTHER'].iloc[0]

st.markdown('<div class="eyebrow">2026 LOCAL GOVERNMENT ELECTION ANALYTICS</div>',unsafe_allow_html=True)
st.title('Johannesburg · Election Lab')
st.markdown('<div class="lede">Historical evidence, transparent models and conditional projections for 4 November 2026.</div>',unsafe_allow_html=True)
st.warning('Exploratory project: only three municipal election years. Selected ward footprints are audited. The candidate slate and 2026 roll remain unverified; earlier metro footprints have small measured changes. Figures are conditional, not certified election forecasts.')
st.caption(f'{kind} · PR ballot · {method} · Provincial scenario weight {weight:.0%}')
a,b,c,d=st.columns(4)
a.metric('Largest named party',str(leader.party),f'{leader.share:.1%} PR share',delta_color='off')
b.metric('Projected participants',f'{t["voters_estimate"]:,.0f}')
c.metric('Projected turnout rate',f'{t["rate_estimate"]:.1%}')
d.metric('Projected valid PR votes',f'{t["pr_valid_estimate"]:,.0f}')
st.caption('Participants use the historical IEC turnout numerator. Rate shown = IEC turnout numerator / (estimated registered roll + estimated MEC7). The MEC7 ratio is carried forward from 2021. PR votes and participants are different quantities.')

colors={'ANC':'#E2A84B','DA':'#4F9FDF','EFF':'#D96B70','ActionSA':'#60BBA8','PA':'#A58BD4','IFP':'#B5A07E','FF+':'#E2CC78','ACDP':'#7896C0','Al Jama-ah':'#8FB58D','OTHER':'#67768C','MK':'#B0BCCB','RISE Mzansi':'#D8B07D'}
def style(fig):
    fig.update_layout(template='plotly_dark',paper_bgcolor='#0D1423',plot_bgcolor='#0D1423',
                      font=dict(color='#C8D4E4'),margin=dict(l=10,r=10,t=30,b=10),legend_title_text='')
    return fig

tabs=st.tabs(['Projection','Historical evidence','Validation','Three wards','Geography & sources'])
with tabs[0]:
    st.subheader('Projected party support')
    left,right=st.columns([1.6,1])
    with left:
        fig=px.bar(table.sort_values('share'),x='share',y='party',orientation='h',color='party',color_discrete_map=colors)
        fig.update_layout(showlegend=False,height=480,xaxis_tickformat='.0%')
        st.plotly_chart(style(fig),width='stretch')
    with right:
        shown=table[['party','share','pr_votes_estimate']].copy()
        if weight==0:
            shown.loc[shown.party.isin(NEW_PARTIES),['share','pr_votes_estimate']]=np.nan
        st.dataframe(shown.rename(columns={'share':'PR share','pr_votes_estimate':'PR vote estimate'}).style.format({'PR share':'{:.1%}','PR vote estimate':'{:,.0f}'},na_rep='Not estimated'),hide_index=True,width='stretch')
        st.caption('OTHER is a residual category, not a party. MK and RISE Mzansi are unestimated by the municipal model; the scenario tab context provides a sensitivity route for new parties. Closed-slate forecasts can miss new entrants.')
        st.download_button('Download current projection',shown.to_csv(index=False),'jhb_projection.csv','text/csv')
    st.subheader('Sensitivity to model and election-type assumptions')
    scenarios=sensitivity(shares,context)
    env=scenarios.groupby('party').share.agg(['min','max']).reset_index()
    st.dataframe(env.style.format({'min':'{:.1%}','max':'{:.1%}'}),hide_index=True,width='stretch')
    st.caption('Min/max over persistence and ridge, with 0%, 25% and 50% provincial blending. This is a scenario envelope, not an 80% or 95% prediction interval.')
    st.subheader('Does the projected leader change across assumptions?')
    st.dataframe(scenario_leaders(shares,context),hide_index=True,width='stretch')
    st.caption('Scenario leaders are outcomes of specified assumptions. Their frequency is not an election-win probability.')
    st.subheader('Coalition arithmetic')
    combos=coalition_arithmetic(table)
    st.markdown('<div class="note">Largest vote share identifies the model’s electoral leader. It does not identify the mayor or governing party. Ward winners, compensatory PR seats, independents, the final council size and coalition agreements are required to assess government formation.</div>',unsafe_allow_html=True)
    if len(combos):
        st.dataframe(combos.style.format({'combined_pr_share':'{:.1%}'}),hide_index=True,width='stretch')
    else:
        st.info('No minimal two- or three-party combination among the six largest named parties exceeds 50% of the projected PR vote share.')
    st.caption('Combinations above 50% are arithmetic illustrations. They are not seat forecasts or predictions of political agreements.')

with tabs[1]:
    st.subheader('Observed municipal PR vote shares')
    long=shares.reset_index().melt(id_vars='year',var_name='party',value_name='share')
    fig=px.line(long,x='year',y='share',color='party',markers=True,color_discrete_map=colors)
    fig.update_layout(yaxis_tickformat='.0%',xaxis=dict(tickmode='array',tickvals=[2011,2016,2021]),height=450)
    st.plotly_chart(style(fig),width='stretch')
    st.dataframe(votes,hide_index=True,width='stretch')
    st.subheader('Observed turnout participants and registration')
    st.dataframe(turnout,hide_index=True,width='stretch')
    st.caption('Source counts are historical observations; OTHER and calculated rates are derived. All municipal model PR cells now reconcile with archived original IEC PDFs. Registered roll and MEC7 totals are archived in the official turnout reports.')
    st.subheader('2024 provincial context — separate ballot')
    st.dataframe(context,hide_index=True,width='stretch')

with tabs[2]:
    st.subheader('Temporal holdout: forecast 2021 using 2011 and 2016')
    st.dataframe(metrics,hide_index=True,width='stretch')
    fig=px.scatter(detail.reset_index().melt(id_vars=['party','actual'],value_vars=['persistence','ridge'],var_name='model',value_name='predicted'),x='actual',y='predicted',color='model',hover_name='party')
    fig.add_shape(type='line',x0=0,y0=0,x1=.5,y1=.5,line=dict(dash='dash',color='#748298'))
    fig.update_layout(xaxis_tickformat='.0%',yaxis_tickformat='.0%')
    st.plotly_chart(style(fig),width='stretch')
    st.dataframe(detail.style.format('{:.1%}'),width='stretch')
    st.subheader('Earlier forecast check and party-count errors')
    rolling,count_errors=rolling_diagnostics(shares,turnout)
    st.dataframe(rolling,hide_index=True,width='stretch')
    st.dataframe(count_errors,hide_index=True,width='stretch')
    st.caption('2016 persistence uses only 2011. Ridge requires at least two election years. These retrospective diagnostics do not create an untouched final test.')
    st.subheader('Turnout model validation')
    st.dataframe(turnout_backtest(turnout),hide_index=True,width='stretch')
    st.info('There is one test election, not ten independent test samples. Model selection uses this holdout, so the winning score is not an unbiased final estimate. No calibrated confidence intervals or election win probabilities are claimed.')
    st.markdown('Ridge learns a penalized linear time trend, using five-year time units and a pre-specified alpha of 0.5. Vote shares are projected onto the probability simplex. Turnout uses a separate logit-scale ridge candidate. The modest sample size excludes defensible tuning of large tree ensembles or deep models.')

with tabs[3]:
    st.subheader('4 November 2026: wards 21, 23 and 87')
    leaders,party_forecasts,ward_metrics=verified_ward_forecasts()
    for col,(_,row) in zip(st.columns(3),leaders.iterrows()):
        with col:
            st.metric(f'2026 ward {row.ward_id[-3:].lstrip("0")}',row.projected_leader,f'{row.leader_share:.1%} ward-ballot share',delta_color='off')
            st.caption(f'Model: {row.model} · Comparable history: {row.history_years}')
    st.dataframe(leaders,hide_index=True,width='stretch')
    st.markdown('Ward 21 has a comparable three-election history and an ANC lead. Ward 23 offers a more divided DA/ActionSA case. Ward 87 has a DA majority and a comparable 2016 history. Selection prioritizes audited 2026 footprints and contrasting histories, not population representativeness.')
    st.info('These are conditional forecasts on audited target wards. New entrants and candidate effects remain unmodelled. Ward 23 has only one comparable general election and cannot support historical forecast validation.')
    st.subheader('Projected ward party shares')
    st.dataframe(party_forecasts,hide_index=True,width='stretch')
    st.subheader('Historical ward validation')
    st.dataframe(ward_metrics,hide_index=True,width='stretch')
    st.caption('Shares use ward ballots. One retrospective test is not enough to calibrate win probabilities. The baseline is retained when its share MAE is lower.')
    st.subheader('Actual boundary evidence')
    geometry=json.loads((Path(__file__).parent/'data/raw/jhb_wards_2026.geojson').read_text())
    map_figure=go.Figure()
    selected_ids=set(leaders.ward_id)
    for feature in geometry['features']:
        ward_id=str(feature['properties']['WardID'])
        rings=feature['geometry']['coordinates']
        if feature['geometry']['type']=='Polygon': rings=[rings]
        for polygon in rings:
            coordinates=polygon[0]
            selected_ward=ward_id in selected_ids
            map_figure.add_trace(go.Scatter(
                x=[p[0] for p in coordinates],y=[p[1] for p in coordinates],
                mode='lines',fill='toself' if selected_ward else None,
                line=dict(color='#E2A84B' if selected_ward else '#526174',width=2 if selected_ward else .5),
                name=f'2026 ward {int(ward_id[-3:])}',showlegend=False,
                hovertemplate=f'2026 ward {int(ward_id[-3:])}<extra></extra>'))
    map_figure.update_layout(height=500,xaxis_title='Longitude',yaxis_title='Latitude')
    map_figure.update_yaxes(scaleanchor='x',scaleratio=1.16)
    st.plotly_chart(style(map_figure),width='stretch')
    st.caption('Actual MDB 2026 polygons. Gold outlines identify the three analysed wards; no vote distribution is inferred from area.')
    st.dataframe(pd.read_csv(Path(__file__).parent/'data/selected_ward_geometry.csv'),hide_index=True,width='stretch')
    st.caption('Admitted histories differ from the target by less than 1 mm Hausdorff distance and 0.0001% area. Changed historical footprints are excluded, including 2011 for ward 87 and 2011/2016 for ward 23.')

with tabs[4]:
    st.subheader('Geographic comparability')
    st.dataframe(pd.read_csv(Path(__file__).parent/'data/geography_audit.csv'),hide_index=True,width='stretch')
    st.markdown('Use final MDB polygons and IEC voting-district genealogies. Reaggregate stable districts to the final 2026 wards. For split districts, use documented elector-weighted fractions, retain uncertainty and conserve source vote totals. A station point or matching identifier does not establish an unchanged district boundary. Metro outer-boundary continuity must also be checked.')
    st.subheader('Cell-level verification audit')
    st.dataframe(pd.read_csv(Path(__file__).parent/'data/verification_audit.csv'),hide_index=True,width='stretch')
    st.caption('Every municipal model PR cell is reconciled with the archived original report and its file hash. OTHER remains a derived residual.')
    st.subheader('Evidence register')
    st.dataframe(sources,hide_index=True,width='stretch')
    for _,source in sources.iterrows():
        st.markdown(f'[{source.title}]({source.url})')
    st.download_button('Download evidence register',sources.to_csv(index=False),'jhb_sources.csv','text/csv')
    st.subheader('Assessment completion requirements')
    st.markdown('Original IEC exports and selected ward crosswalk are now archived. Remaining work: verify the 2026 candidate slate and registered roll; align earlier metro outer-boundary changes at voting-district level; expand temporal validation. Census and service-delivery features should be included only after consistent geographic alignment and a dated availability audit.')
