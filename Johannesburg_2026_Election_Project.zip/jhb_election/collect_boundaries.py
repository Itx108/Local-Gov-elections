"""Reproduce MDB boundary snapshots through public feature-service queries.

2026 DATE attribute is the election's effective date, not a result observation.
Archive item metadata to inspect dataset availability independently of that date.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request,urlopen
from urllib.parse import urlencode
import json,hashlib
from datetime import datetime,timezone
from shapely.geometry import shape,mapping
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parent
BASE='https://services7.arcgis.com/oeoyTUJC8HEeYsRB/arcgis/rest/services/'
LAYERS={2011:('MDB_Wards_2011','LocalMunicipalityCode','97cb14748cef423a94f7b7154387b2dc'),
        2016:('MDB_Wards_2016','LocalMunicipalityCode','a19b92da789f4c949f17a88d14690568'),
        2021:('SA_Wards2020','CAT_B','9092c804a70a49efa40932082eacdb55'),
        2026:('MDB_Wards_2026','CAT_B','30b6e281a5074eddbf1a3f82aa00459e')}

def download(url):
    with urlopen(Request(url,headers={'User-Agent':'Johannesburg academic election analytics'}),timeout=30) as response:
        return response.read()

def collect(year):
    layer,field,item=LAYERS[year]
    url=BASE+layer+'/FeatureServer/0/query?'+urlencode({'where':f"{field}='JHB'",'outFields':'*','outSR':4326,'f':'geojson'})
    raw=download(url);document=json.loads(raw)
    assert document.get('type')=='FeatureCollection',document
    assert not document.get('exceededTransferLimit'), 'Incomplete geometry response'
    root=ROOT/'data/raw';root.mkdir(exist_ok=True)
    (root/f'jhb_wards_{year}.geojson').write_bytes(raw)
    metadata=download(f'https://www.arcgis.com/sharing/rest/content/items/{item}?f=json')
    (root/f'{item}_metadata.json').write_bytes(metadata)
    (root/f'jhb_wards_{year}_source.json').write_text(json.dumps({
        'url':url,'sha256':hashlib.sha256(raw).hexdigest(),'retrieved':datetime.now(timezone.utc).isoformat(),
        'item_id':item,'owner':json.loads(metadata).get('owner'),
        'item_modified_epoch_ms':json.loads(metadata).get('modified')},indent=2))
    if year==2011:
        groups={}
        for feature in document['features']:
            groups.setdefault(str(feature['properties']['WardID']),[]).append(feature)
        features=[]
        for ward,group in groups.items():
            feature=group[0].copy()
            feature['geometry']=mapping(unary_union([shape(f['geometry']) for f in group]))
            features.append(feature)
        (root/'jhb_wards_2011_dissolved.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features}))
        print('2011 within-year dissolve:',len(document['features']),'features ->',len(features),'wards')
    print(year,len(document['features']),'raw features archived')

if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(collect,LAYERS))
